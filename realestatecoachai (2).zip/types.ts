export enum AppState {
  LANDING = 'LANDING',
  SETUP = 'SETUP',
  ACTIVE_CALL = 'ACTIVE_CALL',
  ANALYZING = 'ANALYZING',
  REPORT = 'REPORT',
}

export type Language = 'English' | 'Arabic' | 'Hindi/Urdu';

export type VoiceName = 'Puck' | 'Charon' | 'Kore' | 'Fenrir' | 'Zephyr';

export interface Persona {
  id: string;
  name: string;
  description: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  icon: string;
  voiceName: VoiceName; // The default recommended voice
  gender: 'Male' | 'Female';
  accent: string;
  instructions: string; // Internal acting notes for the AI
  openingLine: string; // Typical way this person answers the phone
}

export interface ChatMessage {
  role: 'user' | 'model' | 'system';
  text: string;
  timestamp: number;
}

export interface AudioVisualizerData {
  volume: number;
}