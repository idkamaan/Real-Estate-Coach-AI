import React, { useEffect, useRef } from 'react';

interface VisualizerProps {
  isActive: boolean;
}

const Visualizer: React.FC<VisualizerProps> = ({ isActive }) => {
  const barsRef = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    if (!isActive) {
       // Reset bars to resting state immediately when not active
       barsRef.current.forEach((bar) => {
         if (bar) bar.style.height = '10%';
       });
       return;
    }

    const interval = setInterval(() => {
      barsRef.current.forEach((bar) => {
        if (bar) {
          const height = Math.random() * 80 + 20; // Random height between 20% and 100%
          bar.style.height = `${height}%`;
        }
      });
    }, 100);

    return () => clearInterval(interval);
  }, [isActive]);

  return (
    <div className="flex items-center justify-center gap-1 h-16 w-32">
      {[...Array(5)].map((_, i) => (
        <div
          key={i}
          ref={(el) => {
            if (el) barsRef.current[i] = el;
          }}
          className={`w-2 rounded-full transition-all duration-150 ease-in-out ${
            isActive ? 'bg-indigo-400 shadow-[0_0_10px_rgba(129,140,248,0.5)]' : 'bg-slate-700 h-2'
          }`}
          style={{ height: '10%' }}
        />
      ))}
    </div>
  );
};

export default Visualizer;