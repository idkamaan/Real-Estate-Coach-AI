import React from 'react';
import { Persona } from '../types';

interface PersonaCardProps {
  persona: Persona;
  selected: boolean;
  onClick: () => void;
}

const PersonaCard: React.FC<PersonaCardProps> = ({ persona, selected, onClick }) => {
  return (
    <div
      onClick={onClick}
      className={`cursor-pointer p-5 rounded-xl border-2 transition-all duration-200 flex flex-col gap-3
        ${selected
          ? 'border-indigo-500 bg-indigo-500/10 shadow-lg shadow-indigo-500/20'
          : 'border-slate-700 bg-slate-800/50 hover:border-slate-500 hover:bg-slate-800'
        }
      `}
    >
      <div className="flex justify-between items-start">
        <div className="text-4xl">{persona.icon}</div>
        <div className={`px-2 py-1 rounded text-xs font-semibold
          ${persona.difficulty === 'Easy' ? 'bg-green-500/20 text-green-400' :
            persona.difficulty === 'Medium' ? 'bg-yellow-500/20 text-yellow-400' :
            'bg-red-500/20 text-red-400'}
        `}>
          {persona.difficulty}
        </div>
      </div>
      <div>
        <h3 className="text-lg font-bold text-slate-100">{persona.name}</h3>
        <p className="text-sm text-slate-400 mt-1 leading-relaxed">{persona.description}</p>
      </div>
    </div>
  );
};

export default PersonaCard;
