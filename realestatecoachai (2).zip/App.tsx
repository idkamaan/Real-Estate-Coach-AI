import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { 
  PhoneOff, RotateCcw, Loader2, Clock, 
  ChevronRight, User, Mail, Sparkles, Globe, Mic2, 
  ChevronDown, Check, Play, BarChart3, Shield, Zap,
  TrendingUp, Award, AlertTriangle, Lightbulb
} from 'lucide-react';

import { AppState, Persona, ChatMessage, Language, VoiceName } from './types';
import { PERSONAS, SYSTEM_INSTRUCTION_BASE, LANGUAGES } from './constants';
import { createPcmBlob, decodeAudioData, base64ToUint8Array, resampleTo16k } from './utils/audioUtils';
import PersonaCard from './components/PersonaCard';
import Visualizer from './components/Visualizer';
import { generateEvaluationReport } from './services/gemini';

// --- MODERN UI COMPONENTS ---

const GlassCard = ({ children, className = "" }: { children?: React.ReactNode; className?: string }) => (
  <div className={`bg-white/5 backdrop-blur-xl border border-white/10 shadow-2xl rounded-2xl ${className}`}>
    {children}
  </div>
);

const ModernSelect = ({ 
  label, 
  value, 
  onChange, 
  options, 
  icon: Icon 
}: { 
  label: string; 
  value: string; 
  onChange: (val: string) => void; 
  options: { label: string; value: string; group?: string }[];
  icon: any;
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (ref.current && !ref.current.contains(event.target as Node)) setIsOpen(false);
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const selectedLabel = options.find(o => o.value === value)?.label || value;

  return (
    <div className="relative" ref={ref}>
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg px-3 py-2 text-sm transition-all w-full min-w-[140px] justify-between group"
      >
        <div className="flex items-center gap-2 text-slate-300">
          <Icon className="w-4 h-4 text-indigo-400 group-hover:text-indigo-300" />
          <span className="font-medium text-slate-200">{selectedLabel}</span>
        </div>
        <ChevronDown className={`w-3 h-3 text-slate-500 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      
      {isOpen && (
        <div className="absolute top-full mt-2 left-0 w-full min-w-[180px] bg-[#0f172a] border border-white/10 rounded-lg shadow-xl overflow-hidden z-50 animate-in fade-in zoom-in-95 duration-100">
           <div className="max-h-60 overflow-y-auto custom-scrollbar p-1">
             {options.map((opt) => (
               <button
                 key={opt.value}
                 onClick={() => { onChange(opt.value); setIsOpen(false); }}
                 className={`w-full text-left px-3 py-2 text-sm rounded-md flex items-center justify-between transition-colors
                   ${value === opt.value ? 'bg-indigo-500/20 text-indigo-300' : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'}
                 `}
               >
                 {opt.label}
                 {value === opt.value && <Check className="w-3 h-3" />}
               </button>
             ))}
           </div>
        </div>
      )}
    </div>
  );
};

const CircularProgress = ({ score }: { score: number }) => {
  const radius = 50;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;
  
  // Determine color based on score
  const colorClass = score >= 80 ? 'text-green-500' : score >= 60 ? 'text-yellow-500' : 'text-red-500';

  return (
    <div className="relative flex items-center justify-center w-32 h-32">
      <svg className="transform -rotate-90 w-full h-full">
        <circle cx="64" cy="64" r={radius} stroke="currentColor" strokeWidth="8" fill="transparent" className="text-slate-800" />
        <circle
          cx="64" cy="64" r={radius} stroke="currentColor" strokeWidth="8" fill="transparent"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          className={`${colorClass} transition-all duration-1000 ease-out`}
        />
      </svg>
      <div className="absolute flex flex-col items-center">
        <span className={`text-3xl font-bold ${colorClass}`}>{score}</span>
        <span className="text-xs text-slate-500 uppercase font-medium">Overall</span>
      </div>
    </div>
  );
};

const MetricBar = ({ label, score, max = 10 }: { label: string; score: number; max?: number }) => {
  const percentage = Math.min(100, (score / max) * 100);
  const colorClass = percentage >= 80 ? 'bg-green-500' : percentage >= 60 ? 'bg-yellow-500' : 'bg-red-500';
  
  return (
    <div className="w-full mb-4">
      <div className="flex justify-between text-sm mb-1.5">
        <span className="text-slate-300 font-medium">{label}</span>
        <span className="text-slate-400 font-mono">{score}/{max}</span>
      </div>
      <div className="h-2.5 w-full bg-slate-800 rounded-full overflow-hidden">
        <div 
          className={`h-full rounded-full ${colorClass} transition-all duration-1000 ease-out`} 
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
};

const InsightCard = ({ title, icon: Icon, children, color }: { title: string; icon: any; children: React.ReactNode; color: string }) => (
  <div className="bg-white/5 border border-white/5 rounded-xl p-5 hover:bg-white/10 transition-colors">
    <div className={`flex items-center gap-2 mb-3 ${color}`}>
      <Icon className="w-5 h-5" />
      <h3 className="font-bold text-sm uppercase tracking-wide">{title}</h3>
    </div>
    <div className="text-slate-300 text-sm leading-relaxed">
      {children}
    </div>
  </div>
);

// --- APP COMPONENT ---

const App: React.FC = () => {
  // State
  const [appState, setAppState] = useState<AppState>(AppState.LANDING);
  const [selectedPersona, setSelectedPersona] = useState<Persona | null>(null);
  const [selectedLanguage, setSelectedLanguage] = useState<Language>('English');
  const [selectedDifficulty, setSelectedDifficulty] = useState<'All' | 'Easy' | 'Medium' | 'Hard'>('All');
  const [selectedVoice, setSelectedVoice] = useState<VoiceName | null>(null);
  
  const [transcripts, setTranscripts] = useState<ChatMessage[]>([]);
  const [report, setReport] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [callDuration, setCallDuration] = useState<number>(0);
  const [isConnecting, setIsConnecting] = useState(false);
  
  const [userName, setUserName] = useState('');
  const [userEmail, setUserEmail] = useState('');

  // Audio State
  const [isSessionActive, setIsSessionActive] = useState(false);
  const [isModelSpeaking, setIsModelSpeaking] = useState(false);
  const [isUserSpeaking, setIsUserSpeaking] = useState(false);

  // Refs
  const isModelSpeakingRef = useRef(false);
  const lastModelSpeakingTimeRef = useRef(0);
  const activeSessionRef = useRef<any>(null);
  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const userSpeakingTimeoutRef = useRef<any>(null);
  const transcriptContainerRef = useRef<HTMLDivElement>(null);
  
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const inputStreamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  useEffect(() => {
    if (selectedPersona) setSelectedVoice(selectedPersona.voiceName);
  }, [selectedPersona]);

  const resetAudioState = () => {
    nextStartTimeRef.current = 0;
    sourcesRef.current.forEach(source => { try { source.stop(); } catch (e) {} });
    sourcesRef.current.clear();
  };

  useEffect(() => {
    let interval: any;
    if (appState === AppState.ACTIVE_CALL && isSessionActive) {
      interval = setInterval(() => setCallDuration(prev => prev + 1), 1000);
    }
    return () => clearInterval(interval);
  }, [appState, isSessionActive]);

  useEffect(() => {
    if (transcriptContainerRef.current) {
      transcriptContainerRef.current.scrollTop = transcriptContainerRef.current.scrollHeight;
    }
  }, [transcripts]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const filteredPersonas = PERSONAS.filter(p => 
    selectedDifficulty === 'All' ? true : p.difficulty === selectedDifficulty
  );

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (userName.trim() && userEmail.trim()) setAppState(AppState.SETUP);
  };

  const startCall = async () => {
    if (!selectedPersona || !process.env.API_KEY) {
      setError("Configuration Error. Please check API Key.");
      return;
    }

    setIsConnecting(true);
    setAppState(AppState.ACTIVE_CALL);
    setCallDuration(0);
    setError(null);
    setTranscripts([]);
    resetAudioState();
    setIsUserSpeaking(false);
    setIsModelSpeaking(false);
    isModelSpeakingRef.current = false;
    lastModelSpeakingTimeRef.current = 0;
    activeSessionRef.current = null;

    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      try { inputAudioContextRef.current = new AudioContextClass({ sampleRate: 16000 }); } 
      catch (e) { inputAudioContextRef.current = new AudioContextClass(); }
      
      try { outputAudioContextRef.current = new AudioContextClass({ sampleRate: 24000 }); } 
      catch (e) { outputAudioContextRef.current = new AudioContextClass(); }
      
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: { channelCount: 1, echoCancellation: true, autoGainControl: true, noiseSuppression: true } 
      });
      inputStreamRef.current = stream;

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const systemInstruction = `${SYSTEM_INSTRUCTION_BASE}
      SESSION CONFIG:
      - LANGUAGE: ${selectedLanguage}. (Speak ONLY in this language).
      - PERSONA: ${selectedPersona.name} (${selectedPersona.gender}, ${selectedPersona.accent}).
      - NOTES: ${selectedPersona.instructions}
      - USER: "${userName}"
      - OPENING: Say "${selectedPersona.openingLine}" THEN WAIT.
      `;
      
      const finalInstructions = systemInstruction
        .replace(/{gender}/g, selectedPersona.gender)
        .replace(/{accent}/g, selectedPersona.accent);

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction: finalInstructions,
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: selectedVoice || 'Puck' } } },
          inputAudioTranscription: {}, 
          outputAudioTranscription: {}, 
        },
        callbacks: {
          onopen: async () => {
            if (!inputAudioContextRef.current || !inputStreamRef.current) return;
            if (inputAudioContextRef.current.state === 'suspended') await inputAudioContextRef.current.resume();

            const source = inputAudioContextRef.current.createMediaStreamSource(inputStreamRef.current);
            const processor = inputAudioContextRef.current.createScriptProcessor(4096, 1, 1);
            processorRef.current = processor;
            
            processor.onaudioprocess = (e) => {
              const inputCtx = inputAudioContextRef.current;
              if (!inputCtx) return;

              let inputData = e.inputBuffer.getChannelData(0);
              let sum = 0;
              for (let i = 0; i < inputData.length; i++) sum += inputData[i] * inputData[i];
              const rms = Math.sqrt(sum / inputData.length);

              const isGateActive = isModelSpeakingRef.current || (Date.now() - lastModelSpeakingTimeRef.current < 800);
              const threshold = isGateActive ? 0.1 : 0.01;

              if (rms > threshold) { 
                setIsUserSpeaking(true);
                if (userSpeakingTimeoutRef.current) clearTimeout(userSpeakingTimeoutRef.current);
                userSpeakingTimeoutRef.current = setTimeout(() => setIsUserSpeaking(false), 500);
              } else {
                 for (let i = 0; i < inputData.length; i++) inputData[i] = 0;
              }

              if (inputCtx.sampleRate !== 16000) inputData = resampleTo16k(inputData, inputCtx.sampleRate);

              const pcmBlob = createPcmBlob(inputData);
              sessionPromise.then((session: any) => {
                  if (session?.sendRealtimeInput) session.sendRealtimeInput({ media: pcmBlob });
              });
            };
            
            const silence = inputAudioContextRef.current.createGain();
            silence.gain.value = 0;
            source.connect(processor);
            processor.connect(silence);
            silence.connect(inputAudioContextRef.current.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(source => { try { source.stop(); } catch (e) {} });
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
              setIsModelSpeaking(false);
              isModelSpeakingRef.current = false;
              lastModelSpeakingTimeRef.current = Date.now();
            }

            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio && outputAudioContextRef.current) {
              setIsModelSpeaking(true);
              isModelSpeakingRef.current = true;
              const ctx = outputAudioContextRef.current;
              if (ctx.state === 'suspended') await ctx.resume();
              
              const now = ctx.currentTime;
              if (nextStartTimeRef.current < now) nextStartTimeRef.current = now + 0.05; 

              const audioBuffer = await decodeAudioData(base64ToUint8Array(base64Audio), ctx, 24000);
              const source = ctx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(ctx.destination);
              source.onended = () => {
                sourcesRef.current.delete(source);
                if (sourcesRef.current.size === 0) {
                  setIsModelSpeaking(false);
                  isModelSpeakingRef.current = false;
                  lastModelSpeakingTimeRef.current = Date.now();
                }
              };
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              sourcesRef.current.add(source);
            }
            
            if (message.serverContent?.inputTranscription?.text) {
               const text = message.serverContent.inputTranscription.text;
               if (text.toLowerCase().includes("end call")) endCall();
               setTranscripts(prev => {
                  const last = prev[prev.length - 1];
                  return (last && last.role === 'user') 
                    ? [...prev.slice(0, -1), { ...last, text: last.text + text }]
                    : [...prev, { role: 'user', text, timestamp: Date.now() }];
               });
            }

            if (message.serverContent?.outputTranscription?.text) {
                 const text = message.serverContent.outputTranscription.text;
                 setTranscripts(prev => {
                    const last = prev[prev.length - 1];
                    return (last && last.role === 'model') 
                      ? [...prev.slice(0, -1), { ...last, text: last.text + text }]
                      : [...prev, { role: 'model', text, timestamp: Date.now() }];
                 });
            }
          },
          onclose: () => {
            setIsSessionActive(false);
            setIsModelSpeaking(false);
            setIsUserSpeaking(false);
            isModelSpeakingRef.current = false;
          },
          onerror: (err) => {
            if (err instanceof Error && (err.message.includes("invalid argument") || err.message.includes("internal error"))) {
                setError("Configuration Error. Please try a different voice.");
                endCall(false);
            }
          }
        }
      });
      
      sessionPromiseRef.current = sessionPromise;
      const session = await sessionPromise;
      activeSessionRef.current = session;
      setIsSessionActive(true);
      setIsConnecting(false);
      
    } catch (err: any) {
      setIsConnecting(false);
      setError(err.name === 'NotAllowedError' ? "Microphone access denied." : "Connection failed.");
      setAppState(AppState.SETUP);
    }
  };

  const endCall = async (generateReport = true) => {
    if (processorRef.current) { processorRef.current.disconnect(); processorRef.current = null; }
    if (inputStreamRef.current) { inputStreamRef.current.getTracks().forEach(t => t.stop()); inputStreamRef.current = null; }
    if (outputAudioContextRef.current) { outputAudioContextRef.current.close(); outputAudioContextRef.current = null; }
    if (inputAudioContextRef.current) { inputAudioContextRef.current.close(); inputAudioContextRef.current = null; }
    
    activeSessionRef.current = null;
    if (sessionPromiseRef.current) {
        try { const session = await sessionPromiseRef.current; if (session.close) session.close(); } catch (e) {}
    }

    setIsSessionActive(false);
    setIsUserSpeaking(false);
    setIsModelSpeaking(false);
    isModelSpeakingRef.current = false;
    
    if (generateReport) {
      setAppState(AppState.ANALYZING);
      const reportText = await generateEvaluationReport(transcripts);
      setReport(reportText);
      setAppState(AppState.REPORT);
    } else {
      setAppState(AppState.SETUP);
    }
  };

  // Helper to extract stats from the raw report text
  const extractScore = (text: string, regex: RegExp) => {
    const match = text.match(regex);
    return match ? parseInt(match[1]) : 0;
  };

  const formatReportBody = (text: string) => {
     // Remove the specific score headers that we are visualizing separately to avoid duplication
     let cleanText = text
       .replace(/Overall Score.*?\/100/i, '')
       .replace(/Buyer Qualification.*?\/10/i, '')
       .replace(/Objection Handling.*?\/10/i, '')
       .replace(/#+\s?7\.\s?Overall Score.*/i, '');
     
     // Simple markdown styling
     return cleanText.split('\n').map((line, i) => {
        if (line.match(/^#+\s/)) {
          return <h3 key={i} className="text-lg font-bold text-indigo-400 mt-6 mb-2">{line.replace(/^#+\s/, '')}</h3>;
        }
        if (line.match(/^\d+\./)) {
           return <p key={i} className="font-semibold text-slate-200 mt-3 mb-1">{line}</p>;
        }
        if (line.trim().startsWith('-')) {
           return <li key={i} className="text-slate-400 ml-4 mb-1 list-disc">{line.replace(/^-/, '').trim()}</li>;
        }
        return <p key={i} className="text-slate-300 mb-2 leading-relaxed">{line.replace(/\*\*(.*?)\*\*/g, '$1')}</p>;
     });
  };

  // --- RENDER VIEWS ---

  if (appState === AppState.LANDING) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 relative overflow-hidden">
        <GlassCard className="w-full max-w-md p-8 relative z-10 animate-float">
          <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-24 h-24 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-[0_0_40px_rgba(79,70,229,0.5)] rotate-3 border border-white/20">
            <Sparkles className="w-12 h-12 text-white" />
          </div>
          
          <div className="mt-12 text-center mb-8">
            <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-2">
              RealEstate Coach AI
            </h1>
            <p className="text-slate-400 text-sm">Next-Gen Sales Simulation Training</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div className="group">
              <div className="relative">
                <User className="absolute left-3 top-3 w-5 h-5 text-indigo-400 transition-colors group-hover:text-pink-400" />
                <input 
                  type="text" required value={userName} onChange={e => setUserName(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-10 pr-4 text-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all placeholder:text-slate-600"
                  placeholder="Agent Name"
                />
              </div>
            </div>
            <div className="group">
              <div className="relative">
                <Mail className="absolute left-3 top-3 w-5 h-5 text-indigo-400 transition-colors group-hover:text-pink-400" />
                <input 
                  type="email" required value={userEmail} onChange={e => setUserEmail(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-10 pr-4 text-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all placeholder:text-slate-600"
                  placeholder="Agent Email"
                />
              </div>
            </div>
            <button type="submit" className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold py-3.5 rounded-xl shadow-lg shadow-indigo-500/25 transition-all hover:scale-[1.02] flex items-center justify-center gap-2 mt-4">
              Enter Simulation <ChevronRight className="w-5 h-5" />
            </button>
          </form>
        </GlassCard>
      </div>
    );
  }

  if (appState === AppState.SETUP) {
    return (
      <div className="min-h-screen flex flex-col p-4 md:p-8 max-w-7xl mx-auto">
        {/* Top Bar */}
        <header className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-500/20">
               <Zap className="w-6 h-6 text-white" />
             </div>
             <div>
               <h1 className="text-xl font-bold text-slate-100">Training Setup</h1>
               <div className="flex items-center gap-2 text-xs text-slate-400">
                  <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                  System Online
               </div>
             </div>
          </div>
          <div className="flex items-center gap-3 bg-white/5 px-4 py-2 rounded-full border border-white/10">
             <User className="w-4 h-4 text-indigo-400" />
             <span className="text-sm font-medium text-slate-300">{userName}</span>
          </div>
        </header>

        {/* Filters */}
        <GlassCard className="p-4 mb-8 flex flex-col lg:flex-row gap-4 justify-between items-center z-20 relative">
          <div className="flex flex-wrap gap-3 w-full lg:w-auto">
             <ModernSelect 
               label="Language" 
               value={selectedLanguage} 
               onChange={(v) => setSelectedLanguage(v as Language)}
               options={LANGUAGES.map(l => ({ label: l, value: l }))}
               icon={Globe}
             />
             <ModernSelect 
               label="Voice" 
               value={selectedVoice || ''} 
               onChange={(v) => setSelectedVoice(v as VoiceName)}
               options={[
                 { label: 'Fenrir (Male, Deep)', value: 'Fenrir' },
                 { label: 'Charon (Male, Rough)', value: 'Charon' },
                 { label: 'Puck (Male, Clear)', value: 'Puck' },
                 { label: 'Kore (Female, Calm)', value: 'Kore' },
                 { label: 'Zephyr (Female, Soft)', value: 'Zephyr' }
               ]}
               icon={Mic2}
             />
          </div>
          
          <div className="flex bg-black/20 p-1 rounded-lg border border-white/5">
             {['All', 'Easy', 'Medium', 'Hard'].map((lvl) => (
                <button
                  key={lvl}
                  onClick={() => setSelectedDifficulty(lvl as any)}
                  className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all ${
                    selectedDifficulty === lvl 
                      ? 'bg-indigo-500 text-white shadow-lg' 
                      : 'text-slate-500 hover:text-slate-300'
                  }`}
                >
                  {lvl.toUpperCase()}
                </button>
             ))}
          </div>
        </GlassCard>

        {error && (
          <div className="bg-red-500/10 border border-red-500/20 text-red-200 p-4 rounded-xl mb-6 flex items-center gap-3 animate-in slide-in-from-top-2">
            <Shield className="w-5 h-5 text-red-400" />
            {error}
          </div>
        )}

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 pb-24">
          {filteredPersonas.map((persona) => (
            <PersonaCard
              key={persona.id}
              persona={persona}
              selected={selectedPersona?.id === persona.id}
              onClick={() => setSelectedPersona(persona)}
            />
          ))}
        </div>

        {/* Floating Start Button */}
        <div className="fixed bottom-8 left-0 right-0 flex justify-center z-50 pointer-events-none">
          <button
            onClick={startCall}
            disabled={!selectedPersona || isConnecting}
            className={`pointer-events-auto group relative px-8 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-2xl font-bold text-lg shadow-[0_0_30px_rgba(79,70,229,0.4)] transition-all hover:scale-105 hover:shadow-[0_0_50px_rgba(79,70,229,0.6)] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 flex items-center gap-3 border border-white/20`}
          >
            {isConnecting ? <Loader2 className="w-6 h-6 animate-spin" /> : <Play className="w-6 h-6 fill-current" />}
            {isConnecting ? 'CONNECTING...' : 'START NEW CALL'}
            <div className="absolute inset-0 rounded-2xl bg-white/20 blur opacity-0 group-hover:opacity-100 transition-opacity" />
          </button>
        </div>
      </div>
    );
  }

  if (appState === AppState.ACTIVE_CALL && selectedPersona) {
    return (
      <div className="fixed inset-0 h-[100dvh] flex flex-col bg-[#050505] overflow-hidden">
        {/* Active Header */}
        <div className="flex-shrink-0 bg-white/5 backdrop-blur border-b border-white/5 p-4 flex items-center justify-between z-10">
          <div className="flex items-center gap-4">
             <div className="relative">
               <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center text-2xl border border-white/10 ${isModelSpeaking ? 'animate-pulse shadow-[0_0_20px_rgba(99,102,241,0.5)]' : ''}`}>
                 {selectedPersona.icon}
               </div>
               <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-black rounded-full flex items-center justify-center">
                 <div className={`w-2.5 h-2.5 rounded-full ${isModelSpeaking ? 'bg-green-500 animate-ping' : 'bg-slate-500'}`} />
               </div>
             </div>
             <div>
               <h2 className="font-bold text-slate-100">{selectedPersona.name}</h2>
               <div className="flex items-center gap-2 text-xs font-mono text-indigo-400">
                  <span className="uppercase tracking-wider">{selectedPersona.difficulty} TIER</span>
               </div>
             </div>
          </div>
          <div className="flex items-center gap-2 bg-black/40 px-3 py-1.5 rounded-lg border border-white/5">
             <Clock className="w-4 h-4 text-slate-400" />
             <span className="font-mono text-indigo-300">{formatTime(callDuration)}</span>
          </div>
        </div>

        {/* Transcript */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 custom-scrollbar scroll-smooth" ref={transcriptContainerRef}>
          <div className="flex justify-center py-4">
             <span className="text-[10px] uppercase tracking-[0.2em] text-slate-600 font-bold">Session Encrypted & Recorded</span>
          </div>
          {transcripts.length === 0 && (
             <div className="flex flex-col items-center justify-center h-full opacity-30">
                <Loader2 className="w-12 h-12 mb-4 animate-spin text-indigo-500" />
                <p className="font-mono text-xs">Awaiting Audio Stream...</p>
             </div>
          )}
          {transcripts.map((t, idx) => (
            <div key={idx} className={`flex ${t.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2`}>
              <div 
                className={`max-w-[85%] md:max-w-[70%] rounded-2xl px-5 py-4 text-sm leading-relaxed shadow-lg backdrop-blur-sm
                  ${t.role === 'user' 
                    ? 'bg-gradient-to-br from-indigo-600 to-blue-600 text-white rounded-br-none border border-white/10' 
                    : 'bg-white/5 text-slate-200 rounded-bl-none border border-white/5'
                  }
                `}
              >
                {t.text}
              </div>
            </div>
          ))}
        </div>

        {/* Control Deck */}
        <div className="flex-shrink-0 bg-[#080808]/90 backdrop-blur-xl border-t border-white/5 p-6 pb-8 flex flex-col items-center gap-6 z-20">
           <div className="w-full max-w-md bg-black/40 rounded-full h-16 flex items-center justify-center border border-white/5 shadow-inner">
               <Visualizer isActive={isUserSpeaking || isModelSpeaking} />
           </div>
           
           <button
            onClick={() => endCall(true)}
            className="group flex items-center gap-2 px-8 py-3 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 rounded-full font-bold transition-all hover:scale-105 active:scale-95 hover:shadow-[0_0_20px_rgba(239,68,68,0.2)]"
          >
            <PhoneOff className="w-5 h-5 group-hover:text-red-300" />
            <span className="tracking-wide text-sm">TERMINATE SESSION</span>
          </button>
        </div>
      </div>
    );
  }

  if (appState === AppState.ANALYZING) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-black relative">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-indigo-900/20 via-black to-black" />
        <Loader2 className="w-16 h-16 text-indigo-500 animate-spin mb-8 relative z-10" />
        <h2 className="text-3xl font-bold mb-2 text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400 relative z-10">
          Analyzing Performance
        </h2>
        <p className="text-slate-500 font-sans text-sm relative z-10">Calculating scores & generating feedback...</p>
      </div>
    );
  }

  if (appState === AppState.REPORT) {
    const overallScore = extractScore(report, /Overall Score.*?(\d+)/i) || 0;
    const qualScore = extractScore(report, /Buyer Qualification.*?(\d+)/i) || 0;
    const objScore = extractScore(report, /Objection Handling.*?(\d+)/i) || 0;

    return (
      <div className="min-h-screen flex flex-col p-4 md:p-8 max-w-6xl mx-auto">
        <header className="flex justify-between items-center mb-8">
           <h2 className="text-2xl font-bold flex items-center gap-3 text-white">
             <BarChart3 className="w-6 h-6 text-indigo-400" />
             Performance Dashboard
           </h2>
           <button
             onClick={() => setAppState(AppState.SETUP)}
             className="flex items-center gap-2 px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl transition-all shadow-lg hover:shadow-indigo-500/25 font-bold text-sm"
           >
             <RotateCcw className="w-4 h-4" />
             Start New Call
           </button>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1">
           {/* Left Column: Metrics */}
           <div className="space-y-6">
              <GlassCard className="p-6 flex flex-col items-center">
                 <h3 className="text-slate-400 font-bold uppercase tracking-wider text-xs mb-6">Overall Score</h3>
                 <CircularProgress score={overallScore} />
              </GlassCard>

              <GlassCard className="p-6">
                 <h3 className="text-slate-400 font-bold uppercase tracking-wider text-xs mb-6 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4" /> Key Metrics
                 </h3>
                 <MetricBar label="Buyer Qualification" score={qualScore} />
                 <MetricBar label="Objection Handling" score={objScore} />
                 <MetricBar label="Closing Skills" score={extractScore(report, /Closing Skills.*?(\d+)/i) || 0} />
              </GlassCard>

              <GlassCard className="p-6">
                 <h3 className="text-slate-400 font-bold uppercase tracking-wider text-xs mb-4 flex items-center gap-2">
                    <Award className="w-4 h-4" /> Quick Summary
                 </h3>
                 <div className="text-sm text-slate-300 leading-relaxed">
                   {/* Simple hack to grab the first paragraph of the summary */}
                   {report.split('##')[1]?.split('\n').slice(1, 4).join(' ').replace(/\*\*/g, '') || "Analysis complete."}
                 </div>
              </GlassCard>
           </div>

           {/* Right Column: Detailed Feed */}
           <div className="lg:col-span-2 flex flex-col gap-6">
              <GlassCard className="flex-1 p-8 overflow-y-auto custom-scrollbar max-h-[80vh]">
                 <div className="flex items-center gap-2 mb-6 border-b border-white/5 pb-4">
                    <Lightbulb className="w-5 h-5 text-yellow-400" />
                    <h3 className="text-lg font-bold text-white">Coach's Feedback</h3>
                 </div>
                 
                 <div className="space-y-4">
                    {formatReportBody(report)}
                 </div>
              </GlassCard>
           </div>
        </div>
      </div>
    );
  }

  return null;
};

export default App;