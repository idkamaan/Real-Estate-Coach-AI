import { GoogleGenAI } from "@google/genai";
import { EVALUATION_PROMPT } from '../constants';
import { ChatMessage } from '../types';

export const generateEvaluationReport = async (transcript: ChatMessage[]): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY is not defined");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const conversationText = transcript
    .map((t) => `${t.role.toUpperCase()}: ${t.text}`)
    .join('\n');

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        {
          role: 'user',
          parts: [{ text: EVALUATION_PROMPT + conversationText }],
        },
      ],
    });

    return response.text || "No report generated.";
  } catch (error) {
    console.error("Error generating report:", error);
    return "Failed to generate evaluation report. Please try again.";
  }
};
